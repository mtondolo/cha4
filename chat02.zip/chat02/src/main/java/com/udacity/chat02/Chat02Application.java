package com.udacity.chat02;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Chat02Application {

	public static void main(String[] args) {
		SpringApplication.run(Chat02Application.class, args);
	}

}
