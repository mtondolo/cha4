package com.udacity.chat03;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Chat03Application {

	public static void main(String[] args) {
		SpringApplication.run(Chat03Application.class, args);
	}

}
