package com.udacity.chat3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Chat3Application {

	public static void main(String[] args) {
		SpringApplication.run(Chat3Application.class, args);
	}

}
