package com.udacity.chat3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Chat3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
