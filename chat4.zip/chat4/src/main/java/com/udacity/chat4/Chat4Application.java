package com.udacity.chat4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Chat4Application {

	public static void main(String[] args) {
		SpringApplication.run(Chat4Application.class, args);
	}

}
