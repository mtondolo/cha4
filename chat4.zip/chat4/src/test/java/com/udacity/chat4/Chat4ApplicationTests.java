package com.udacity.chat4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Chat4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
