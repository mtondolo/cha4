package com.udacity.chat5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Chat5Application {

	public static void main(String[] args) {
		SpringApplication.run(Chat5Application.class, args);
	}

}
